"""Run final qualification after the serial experiment coordinator completes."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

root=Path(__file__).resolve().parents[1]
os.chdir(root)
env=os.environ.copy()
env.update(PATH=str(root/'.venv/bin')+os.pathsep+env['PATH'],
           MINAGI_GEFEN_ALLOW_CUDA_MINOR_MISMATCH='1',
           MAX_JOBS='2',TORCHINDUCTOR_COMPILE_THREADS='2')
while not Path('runs/muon-controlled-study-complete.txt').exists():
    time.sleep(5)

# Match the auxiliary-only control on the confirmation seeds too. The trial
# helper provides the same external telemetry as every other learning run.
subprocess.run([sys.executable,'-c',
                "from pathlib import Path; from replication.run_muon_screen import trial; "
                "[trial(Path('runs/muon-screen'),'adamw',0.,seed=s,steps=256) for s in (43,44)]"],
               env=env,check=True)

def monitored(tag, command, extra=None):
    print('starting '+tag,flush=True)
    with Path(f'runs/{tag}.log').open('w') as log:
        subprocess.run([sys.executable,'-m','replication.gpu_monitor','--out',
                        f'runs/{tag}.power.json','--',*command],
                       env=env| (extra or {}),stdout=log,stderr=subprocess.STDOUT,check=True)
    print('passed '+tag,flush=True)

monitored('muon-controlled-final-suite',[sys.executable,'-m','unittest','discover','-s','tests','-v'])
cuda_code="import torch, unittest; import tests.test_muon_candidates as t; torch.use_deterministic_algorithms(True); torch._dynamo.config.recompile_limit=64; t.MuonCandidateTests.device='cuda'; unittest.main(module=t,argv=['controlled-cuda'],verbosity=2)"
monitored('muon-controlled-final-cuda',[sys.executable,'-c',cuda_code],
          {'CUBLAS_WORKSPACE_CONFIG':':4096:8'})
monitored('muon-controlled-final-reduction',[sys.executable,'-m','replication.probe_fixed_sonic_reduction'])

weights=Path('/mnt/fast/models/mini-AGI/undertrained/weights')
before=json.loads(Path('runs/muon-checkpoint-before.json').read_text())
after={}
for path in sorted(weights.rglob('*')):
    if path.is_file():
        digest=hashlib.sha256()
        with path.open('rb') as f:
            for chunk in iter(lambda:f.read(8*1024*1024),b''):
                digest.update(chunk)
        after[str(path.relative_to(weights))]={'bytes':path.stat().st_size,'sha256':digest.hexdigest()}
Path('runs/muon-checkpoint-final.json').write_text(json.dumps(after,indent=2)+'\n')
assert before==after,'original checkpoint changed'
print(f'original checkpoint unchanged: {len(after)} files',flush=True)

packages={}
for name in ('torch','triton','nvidia-cutlass-dsl','quack-kernels','sonic-moe','gefen','numpy','nvidia-ml-py'):
    packages[name]=importlib.metadata.version(name)
snapshot=dict(platform=platform.platform(),python=platform.python_version(),packages=packages,
              git_base='b81ae92',git_experiment=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
              cuda_toolkit=subprocess.check_output(['nvcc','--version'],text=True),
              checkpoint_unchanged_files=len(after))
Path('runs/muon-environment-final.json').write_text(json.dumps(snapshot,indent=2)+'\n')
subprocess.run([sys.executable,'-m','replication.summarize_muon_screen'],env=env,check=True)
Path('runs/muon-controlled-verification-complete.txt').write_text('passed\n')
print('all final qualification passed',flush=True)
