"""Render measured tables into the research report after qualification passes."""
import json
from pathlib import Path
import re
import statistics

root=Path(__file__).resolve().parents[1]
assert (root/'runs/muon-controlled-verification-complete.txt').read_text().strip()=='passed'
r=json.loads((root/'replication/results/muon_variants.json').read_text())
names={'adamw':'AdamW','gefen':'Gefen','muon':'Muon','muon_plus':'Muon+',
       'normuon':'NorMuon','dion3_quarter':'Dion3 0.25','dion3_half':'Dion3 0.50'}
lines=['## Results','',
       'Measured on this RTX 5090 with the existing repository environment. The final',
       f"controlled study contains **{r['learning_trial_count']} complete 256-update learning trials**",
       '(27 tuning/control trials plus 14 selected-rate confirmations and two matched',
       'auxiliary-only confirmations), 14 independent eight-update replay runs, and',
       '14 optimizer-only timing probes. Uncontrolled exploratory learning outcomes',
       'are excluded from these tables.','',
       '### Held-out learning','',
       'Lower predictive cross-entropy is better; units are nats per byte/marker token.',
       f"Initial test CE is **{r['initial_test']['mean_ce']:.5f}** for every trial.",
       'Rates were selected on seed-42 tuning loss only. The following are the two',
       'additional data-order seeds, using those fixed rates.','',
       '| Expert optimizer | Selected LR | Test CE, seed 43 | Test CE, seed 44 | Mean test CE |',
       '| --- | ---: | ---: | ---: | ---: |']
for n,q in r['confirmation'].items():
    lines.append(f"| {names[n]} | {q['lr']:g} | {q['seed_test_ce']['43']:.5f} | {q['seed_test_ce']['44']:.5f} | {q['mean_test_ce']:.5f} |")
frozen={str(x['configuration']['seed']):x['final_test']['mean_ce'] for x in r['auxiliary_only_control']}
lines.append(f"| Experts frozen; auxiliary AdamW | 0 | {frozen['43']:.5f} | {frozen['44']:.5f} | {statistics.mean(frozen[s] for s in ('43','44')):.5f} |")
lines += ['',
          'Muon+ and Dion3-quarter have nearly identical means; neither beats AdamW',
          'on both confirmation seeds. Gefen also changes order relative to AdamW.',
          'NorMuon and Dion3-half show no quality advantage here. These results do',
          'not establish a general optimizer ranking, statistical equivalence, or',
          'pretraining convergence. The frozen-expert control shows substantial',
          'adaptation from the common auxiliary optimizer alone.','',
          '### Monitored adaptation cost','',
          'Means across seeds 43/44, 131,072 new model tokens per run. Timing includes',
          'paging, host history transfers, and first-use calibration; it excludes',
          'synthetic optimizer warmup and held-out evaluation. Peak watts and VRAM',
          'are the larger recorded peak across those two runs.','',
          '| Expert optimizer | Train s | New tokens/s | Avg W | Peak W | J/new token | Peak allocated GiB |',
          '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for n,q in r['confirmation'].items():
    lines.append(f"| {names[n]} | {q['mean_training_seconds']:.2f} | {q['mean_tokens_per_second']:.0f} | {q['mean_board_watts']:.1f} | {q['max_sampled_board_watts']:.1f} | {q['mean_board_joules_per_token']:.5f} | {q['max_allocated_gib']:.3f} |")
gf=r['confirmation']['gefen']; dq=r['confirmation']['dion3_quarter']
lines += ['',
          f"Gefen's final-16-step mean is {gf['mean_last16_optimizer_ms']:.1f} ms for the optimizer",
          f"and {gf['mean_last16_full_step_ms']:.1f} ms for the full step; Dion3-quarter's is",
          f"{dq['mean_last16_optimizer_ms']:.1f} / {dq['mean_last16_full_step_ms']:.1f} ms. Gefen's complete short run",
          'is slower despite its faster tail. Its first optimizer step alone takes',
          '3.85 seconds in each run and includes calibration. These tail',
          'windows are descriptive, not a separate matched steady-state throughput',
          'benchmark: learning-dependent routing changes the work. Do not extrapolate',
          'the complete 256-update average to a long training run.','',
          '### Optimizer-only scaling','',
          'These probes use the deterministic execution controls, FP32 parameters and',
          'gradients, and identical fixed correlated gradients. Five seconds are timed',
          'after warmup/settling. Energy per step uses the measured elapsed interval,',
          'not median latency multiplied by watts.','']
for key,label in (('isolated_latency','Eight 512/2048 experts: 25.17 million parameters'),
                  ('isolated_latency_large','Four 4096/16384 experts: 805.31 million parameters')):
    lines += [f'**{label}.**','',
              '| Optimizer | Median ms/step | Avg W | Peak W | J/step | Peak allocated GiB |',
              '| --- | ---: | ---: | ---: | ---: | ---: |']
    for n,q in r[key].items():
        assert q.get('status')!='out_of_memory'
        p=q['external_power']
        lines.append(f"| {names[n]} | {q['median_step_seconds']*1000:.3f} | {p['average_board_power_w']:.1f} | {p['peak_sampled_board_power_w']:.1f} | {q['external_board_joules_per_step']:.3f} | {q['peak_allocated_gib']:.3f} |")
    lines.append('')
lines += ['All seven optimizer probes fit the 75% allocator cap at both geometries.',
          'This does not prove full-model training fits: model computation, activation',
          'storage, paging, and more resident experts are absent from these probes.',
          'The large Muon-family probes reach roughly the board power limit while',
          'taking much longer than AdamW/Gefen. Higher power is not a throughput gain.',
          'Gefen uses less memory than AdamW here but more board energy per isolated',
          'step; its memory, speed and energy tradeoffs are separate measurements.','',
          '### Decision and limits','',
          '**Carry Gefen and Dion3-quarter into the next longer learning study, with',
          'AdamW retained as the reference.** Gefen has the strongest measured memory',
          'and wide-matrix latency case. Dion3-quarter is the most practical tested',
          'Muon-family candidate: its held-out mean is close to Muon+ and its measured',
          'cost is substantially lower. This is a shortlist, not a production optimizer',
          'selection. The trainer still exposes only its existing AdamW/Gefen choices.','',
          'The large-geometry probe also makes orthogonalization an explicit cost to',
          'resolve before selecting a Muon-family optimizer for fast NVFP4 experts.',
          'These available implementations and classic/Keller NS5 settings do not',
          'represent every possible optimized Muon implementation. Gram NS, Polar',
          'Express, other momentum settings, trunk-wide Muon, and native NVFP4',
          'forward/backward quality remain untested. No result here supports claiming',
          'that low-precision learning quality is already qualified.','',
          'A next quality experiment needs longer runs, more seeds and a defensible',
          'document-level data split, while retaining the higher-precision reference.',
          'The measured checkpoint, depth-6 adaptation and tiny held-out ranges are',
          'the limits of the current quality evidence.','',
          '### Verification and retained evidence','']
count=int(re.search(r'Ran (\d+) tests',(root/'runs/muon-controlled-final-suite.log').read_text()).group(1))
lines += [f'- **{count} tests passed** in the complete regression suite; all six candidate',
          '  qualification tests also passed separately on CUDA with deterministic',
          '  controls. Those tests cover all five matrix configurations, bit-identical',
          '  paged/unpaged updates and state, eviction/swaps, missing/zero gradients,',
          '  empty slots, closure paging, lossless NPZ snapshot/resume and RNG preservation.',
          '- Independent-process replay passed for all seven configurations; all seven',
          '  shared-reference-rate 256-update runs exactly matched the eight-update',
          '  oracle prefix. This proves the stated replay checks, not every future',
          '  GPU shape or an independently repeated full 256-update trajectory.',
          '- The fixed Sonic reduction passed output and all-gradient comparisons',
          '  against the PyTorch reference, plus bit-identical checkpoint replay,',
          '  zero-score derivatives, missing tokens and unused experts.',
          '- All **401 original checkpoint files** retained identical sizes and SHA-256',
          '  hashes. Learned weights remained in RAM. No package, driver, service,',
          '  clock or power-limit configuration changed.','',
          'Timestamped external NVML samples include compilation and warmup. The',
          f"largest confirmation-training sample gap is {max(q['max_external_sample_gap_seconds'] for q in r['confirmation'].values()):.3f} seconds.",
          'Sensor averaging and desktop activity limit power/energy precision; sampled',
          'peaks are not guaranteed instantaneous peaks. These timings describe the',
          'controlled research harness, not a promised production-trainer speedup.','',
          '- [Controlled results and complete rate grids](results/muon_variants.json)',
          '- [Verification, environment, archive checksum](results/muon_variants_verification.json)',
          '- [Raw telemetry, traces, replay gates, source snapshots and historical diagnostics](results/muon_variants_evidence.tar.gz)',
          '- [Excluded exploratory aggregate, explicitly unqualified](results/muon_variants_exploratory.json)','']
path=root/'replication/MUON_VARIANTS.md'
text=path.read_text().split('## Results',1)[0]+'\n'.join(lines)
path.write_text(text)
print('Wrote report with',count,'verified suite tests')
