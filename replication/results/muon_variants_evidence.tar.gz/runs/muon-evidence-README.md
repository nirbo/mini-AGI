Final controlled data: runs/muon-screen/ (43 completed 256-update trials and 14 timing probes).
Strict replay gate: runs/muon-deterministic-repro-fixed/ (14 independent eight-update processes).
Qualified final tests: runs/muon-controlled-final-{suite,cuda,reduction}.*
Checkpoint hashes: runs/muon-checkpoint-{before,after,final}.json.
Environment: runs/muon-environment-final.json. Sources: runs/muon-source-snapshot/.
Excluded exploratory data: runs/muon-screen-exploratory/ and the original unpinned
runs/muon-deterministic-repro/. These include failures/partial runs and are NOT
learning-selection evidence. Older driver/test logs are historical, not final checks.
Exploratory artifacts may retain the original output path in their configuration;
their archive directory identifies their status. No model weights are included.
Timestamped NVML samples cover compilation, warmup, evaluation and training.
Raw limiting masks and definitions are retained; sampling includes desktop activity.
