"""Preserve qualified and excluded measurements, without weights or packages."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import tarfile

import torch

root=Path(__file__).resolve().parents[1]
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert (root/'runs/muon-controlled-verification-complete.txt').read_text().strip()=='passed'
report=json.loads((root/'replication/results/muon_variants.json').read_text())
env_path=root/'runs/muon-environment-final.json'
environment=json.loads(env_path.read_text())
environment.update(torch_version=torch.__version__,torch_cuda_build=torch.version.cuda,
                   torch_git_version=torch.version.git_version)
environment['installed_numerical_source_sha256']={}
for package in ('sonicmoe','gefen'):
    package_root=Path(next(iter(importlib.util.find_spec(package).submodule_search_locations)))
    environment['installed_numerical_source_sha256'][package]={
        str(p.relative_to(package_root)):sha(p) for p in sorted(package_root.rglob('*'))
        if p.is_file() and p.suffix in ('.py','.cu','.cuh','.cpp','.h','.hpp')}
env_path.write_text(json.dumps(environment,indent=2)+'\n')
source_files=[p for p in root.glob('replication/*muon*.py')]
source_files += [root/'replication/probe_training_repro.py',root/'replication/probe_fixed_sonic_reduction.py',
                 root/'tests/test_muon_candidates.py',root/'tests/test_muon_study_protocol.py',
                 root/'minagi/optimizers.py',root/'minagi/optim_codec.py',root/'replication/gpu_monitor.py']
source_files += list(root.glob('minagi/*.py'))+[root/'train.py',root/'config.yaml']
for p in source_files:
    dest=root/'runs/muon-source-snapshot'/p.relative_to(root)
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(p.read_bytes())
readme='''Final controlled data: runs/muon-screen/ (43 completed 256-update trials and 14 timing probes).
Strict replay gate: runs/muon-deterministic-repro-fixed/ (14 independent eight-update processes).
Qualified final tests: runs/muon-controlled-final-{suite,cuda,reduction}.*
Checkpoint hashes: runs/muon-checkpoint-{before,after,final}.json.
Environment: runs/muon-environment-final.json. Sources: runs/muon-source-snapshot/.
Excluded exploratory data: runs/muon-screen-exploratory/ and the original unpinned
runs/muon-deterministic-repro/. These include failures/partial runs and are NOT
learning-selection evidence. Older driver/test logs are historical, not final checks.
Exploratory artifacts may retain the original output path in their configuration;
their archive directory identifies their status. No model weights are included.
Timestamped NVML samples cover compilation, warmup, evaluation and training.
Raw limiting masks and definitions are retained; sampling includes desktop activity.
'''
(root/'runs/muon-evidence-README.md').write_text(readme)

paths=[]
for p in sorted((root/'runs').glob('muon*')):
    paths.extend(sorted(p.rglob('*')) if p.is_dir() else [p])
paths.extend([root/'runs/finalize_muon_study.py',Path(__file__).resolve()])
paths=sorted({p for p in paths if p.is_file() and p.name not in
              ('muon-evidence-index.json','muon-archive-verification.log')})
index={str(p.relative_to(root)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in paths}
index_path=root/'runs/muon-evidence-index.json'
index_path.write_text(json.dumps(index,indent=2)+'\n')
paths.append(index_path)
archive=root/'replication/results/muon_variants_evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for p in paths:
        tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    for name,entry in index.items():
        data=tar.extractfile(name).read()
        assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256'],name

checks={}
for tag in ('suite','cuda','reduction'):
    p=root/f'runs/muon-controlled-final-{tag}.power.json'
    telemetry=json.loads(p.read_text())
    assert telemetry['returncode']==0 and not telemetry['errors']
    checks[tag]=dict(log=f'runs/muon-controlled-final-{tag}.log',telemetry=str(p.relative_to(root)),
                     gpu_metadata=telemetry['metadata'],
                     whole_process=telemetry['whole_process'])
    if tag!='reduction':
        match=re.search(r'Ran (\d+) tests?',(root/checks[tag]['log']).read_text())
        assert match
        checks[tag]['test_count']=int(match.group(1))
before=json.loads((root/'runs/muon-checkpoint-before.json').read_text())
assert before==json.loads((root/'runs/muon-checkpoint-final.json').read_text())
verification=dict(status='passed',git_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
                  tests=checks,environment=json.loads((root/'runs/muon-environment-final.json').read_text()),
                  strict_replay=report['reproducibility'],learning_trials=report['learning_trial_count'],
                  optimizer_only_probes=14,original_checkpoint_unchanged_files=len(before),
                  measured_source_sha256=report['measured_source_sha256'],
                  evidence_archive=dict(path=str(archive.relative_to(root)),sha256=sha(archive),bytes=archive.stat().st_size,
                                        verified_file_count=len(index)))
(root/'replication/results/muon_variants_verification.json').write_text(json.dumps(verification,indent=2)+'\n')
print(json.dumps(verification,indent=2))
