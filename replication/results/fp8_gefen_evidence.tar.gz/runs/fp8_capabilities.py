import json
from pathlib import Path
import torch

torch.use_deterministic_algorithms(True)
torch.backends.cuda.matmul.allow_tf32=False
torch.cuda.set_per_process_memory_fraction(.75)
torch.set_num_threads(4)
torch.manual_seed(42)
results=[]
for dtype in (torch.bfloat16,torch.float32):
    for ad,bd in ((torch.float8_e4m3fn,torch.float8_e4m3fn),(torch.float8_e5m2,torch.float8_e4m3fn),(torch.float8_e5m2,torch.float8_e5m2)):
        for rowwise in (False,True):
            a=torch.ones(32,64,device='cuda',dtype=ad)
            b=torch.ones(128,64,device='cuda',dtype=bd).T
            sa=torch.ones((32,1) if rowwise else (1,),device='cuda')
            sb=torch.ones((1,128) if rowwise else (1,),device='cuda')
            tag=dict(backend='torch',out_dtype=str(dtype),a=str(ad),b=str(bd),rowwise=rowwise)
            try:
                y=torch._scaled_mm(a,b,scale_a=sa,scale_b=sb,out_dtype=dtype,use_fast_accum=False)
                torch.cuda.synchronize()
                assert torch.equal(y,torch.full_like(y,64))
                tag['status']='passed'
            except Exception as e: tag.update(status='unsupported',error=repr(e))
            results.append(tag)
from quack.gemm_interface import gemm
for ad,bd in ((torch.float8_e4m3fn,torch.float8_e4m3fn),(torch.float8_e5m2,torch.float8_e4m3fn),(torch.float8_e5m2,torch.float8_e5m2)):
    for batches in (None,2):
        a=torch.ones((32,64) if batches is None else (batches,32,64),device='cuda',dtype=ad)
        w=torch.ones((128,64) if batches is None else (batches,128,64),device='cuda',dtype=bd)
        tag=dict(backend='quack',a=str(ad),b=str(bd),batches=batches)
        try:
            y=gemm(a,w.mT,out_dtype=torch.float32,tuned=False)
            torch.cuda.synchronize()
            assert torch.equal(y,torch.full_like(y,64))
            tag['status']='passed'
        except Exception as e: tag.update(status='unsupported',error=repr(e))
        results.append(tag)
Path('runs/fp8-capabilities.json').write_text(json.dumps(results,indent=2)+'\n')
for row in results: print(json.dumps(row),flush=True)
