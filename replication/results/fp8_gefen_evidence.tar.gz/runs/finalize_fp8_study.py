import hashlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

root=Path(__file__).resolve().parents[1]
os.chdir(root)
while not Path('runs/fp8-study-complete.txt').exists():time.sleep(5)
env=os.environ|dict(PATH=str(root/'.venv/bin')+os.pathsep+os.environ['PATH'],
                   CUBLAS_WORKSPACE_CONFIG=':4096:8',MINAGI_GEFEN_ALLOW_CUDA_MINOR_MISMATCH='1',
                   MINAGI_FP8_TEST_CUDA='1',TORCHINDUCTOR_COMPILE_THREADS='2',MAX_JOBS='2')
print('starting conversion/GEMM attribution profile',flush=True)
with Path('runs/fp8-profile.log').open('w') as log:
    subprocess.run([sys.executable,'-m','replication.gpu_monitor','--out','runs/fp8-profile.power.json','--',
                    sys.executable,'-m','replication.profile_fp8','--out','runs/fp8-profile.json'],env=env,
                   stdout=log,stderr=subprocess.STDOUT,check=True)
print('attribution profile complete',flush=True)
print('starting final full regression suite',flush=True)
with Path('runs/fp8-final-suite.log').open('w') as log:
    subprocess.run([sys.executable,'-m','replication.gpu_monitor','--out','runs/fp8-final-suite.power.json','--',
                    sys.executable,'-m','unittest','discover','-s','tests','-v'],env=env,
                   stdout=log,stderr=subprocess.STDOUT,check=True)
print('final suite passed',flush=True)
before=json.loads(Path('runs/fp8-checkpoint-before.json').read_text())
weights=Path('/mnt/fast/models/mini-AGI/undertrained/weights')
after={}
for p in sorted(weights.rglob('*')):
    if not p.is_file():continue
    digest=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):digest.update(block)
    after[str(p.relative_to(weights))]=dict(bytes=p.stat().st_size,sha256=digest.hexdigest())
Path('runs/fp8-checkpoint-after.json').write_text(json.dumps(after,indent=2)+'\n')
assert before==after,'original checkpoint changed'
print('all original checkpoint files unchanged',len(after),flush=True)
packages={name:importlib.metadata.version(name) for name in
          ('torch','triton','quack-kernels','nvidia-cutlass-dsl','sonic-moe','gefen','numpy','nvidia-ml-py')}
installed={}
for name in ('quack','sonicmoe','gefen'):
    package=Path(next(iter(importlib.util.find_spec(name).submodule_search_locations)))
    installed[name]={str(p.relative_to(package)):hashlib.sha256(p.read_bytes()).hexdigest()
                     for p in sorted(package.rglob('*')) if p.is_file() and p.suffix in ('.py','.cu','.cuh','.cpp','.h','.hpp')}
import torch
environment=dict(platform=platform.platform(),python=platform.python_version(),packages=packages,
                 torch_version=torch.__version__,torch_cuda_build=torch.version.cuda,
                 git_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
                 cuda_toolkit=subprocess.check_output(['nvcc','--version'],text=True),
                 installed_source_sha256=installed)
Path('runs/fp8-environment.json').write_text(json.dumps(environment,indent=2)+'\n')
subprocess.run([sys.executable,'-m','replication.summarize_fp8_screen'],env=env,check=True)
Path('runs/fp8-verification-complete.txt').write_text('passed\n')
print('final verification complete',flush=True)
