"""Archive qualified FP8 measurements and explicitly excluded pilots."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile

root=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert (root/'runs/fp8-verification-complete.txt').read_text().strip()=='passed'
r=json.loads((root/'replication/results/fp8_gefen.json').read_text())
assert r['status']=='passed'
monitors=sorted((root/'runs/fp8-screen').rglob('*.external-power.json'))
assert len(monitors)==19,len(monitors)
for path in monitors:
    telemetry=json.loads(path.read_text())
    assert telemetry['returncode']==0 and not telemetry['errors'],str(path)
sources=list(root.glob('replication/*fp8*.py'))+list(root.glob('minagi/*.py'))
sources += [root/p for p in ('train.py','config.yaml','AGENTS.md','TRAIN.md','replication/FP8_GEFEN.md',
                             'replication/gpu_monitor.py','replication/probe_nvfp4.py',
                             'replication/compare_gefen_training.py','tests/test_fp8_experts.py')]
for p in sources:
    dest=root/'runs/fp8-source-snapshot'/p.relative_to(root)
    dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
(root/'runs/fp8-evidence-README.md').write_text('''Qualified data: runs/fp8-screen/.
Five eight-update replay/cache runs, six matched 256-update learning runs,
and 84 synthetic timing cases in eight files (two repeats, reversed order).
Final full tests: runs/fp8-final-suite.*; standalone FP8 tests: runs/fp8-tests-final.*.
Attribution profile: runs/fp8-profile.* (profiling overhead, not throughput).
The initial profile and exact original collector are retained as fp8-profile-initial*.
The final collector separates device types and groups actual kernel/copy events
to avoid double-counting GPU annotation ranges; numerical functions are unchanged.
Original 401-file checkpoint hashes: runs/fp8-checkpoint-{before,after}.json.
Installed package inventory/source hashes: runs/fp8-environment.json.
Executed source snapshots: runs/fp8-source-snapshot/.
Excluded pilots: runs/fp8-screen-pilot/ and runs/fp8-model-smoke.*.
The pilot linear sweep was interrupted to harden cache lifetime/inference reuse.
Early test failures exposed the compile region's specialization limit; the
final implementation has an explicit per-region limit and passed qualification.
Only the final complete controlled data are used for conclusions. No weights
or package binaries are included. Old report paths can retain their original
output locations; the archive directory identifies their qualification status.
All GPU processes were externally monitored, including compilation and warmup.
''')
paths=[]
for p in sorted((root/'runs').glob('fp8*')):
    paths.extend(sorted(p.rglob('*')) if p.is_dir() else [p])
paths += [root/'runs/finalize_fp8_study.py',Path(__file__).resolve()]
excluded={'fp8-evidence-index.json','fp8-archive-verification.log'}
paths=sorted({p for p in paths if p.is_file() and p.name not in excluded})
index={str(p.relative_to(root)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in paths}
index_path=root/'runs/fp8-evidence-index.json';index_path.write_text(json.dumps(index,indent=2)+'\n')
archive=root/'replication/results/fp8_gefen_evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for p in [*paths,index_path]:tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    for name,entry in index.items():
        data=tar.extractfile(name).read()
        assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256'],name
checks={}
for tag in ('fp8-final-suite','fp8-tests-final','fp8-profile'):
    p=root/f'runs/{tag}.power.json';telemetry=json.loads(p.read_text())
    assert telemetry['returncode']==0 and not telemetry['errors']
    log=(root/f'runs/{tag}.log').read_text()
    count=re.search(r'Ran (\d+) tests?',log)
    checks[tag]=dict(test_count=int(count.group(1)) if count else None,
                     skipped_count=int(re.search(r'skipped=(\d+)',log).group(1)) if 'skipped=' in log else 0,
                     gpu_metadata=telemetry['metadata'],whole_process=telemetry['whole_process'],
                     log=f'runs/{tag}.log',telemetry=str(p.relative_to(root)))
before=json.loads((root/'runs/fp8-checkpoint-before.json').read_text())
after=json.loads((root/'runs/fp8-checkpoint-after.json').read_text());assert before==after
verification=dict(status='passed',git_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
                  tests=checks,learning_trial_count=6,synthetic_timing_cases=len(r['probes']),
                  monitored_experiment_processes=len(monitors),
                  replay_gate=r['reproducibility'],original_checkpoint_unchanged_files=len(before),
                  measured_source_sha256=r['learning_runs'][0]['source_sha256'],
                  environment=json.loads((root/'runs/fp8-environment.json').read_text()),
                  evidence_archive=dict(path=str(archive.relative_to(root)),sha256=sha(archive),
                                        bytes=archive.stat().st_size,verified_file_count=len(index)))
(root/'replication/results/fp8_gefen_verification.json').write_text(json.dumps(verification,indent=2)+'\n')
print(json.dumps({k:v for k,v in verification.items() if k!='environment'},indent=2))
