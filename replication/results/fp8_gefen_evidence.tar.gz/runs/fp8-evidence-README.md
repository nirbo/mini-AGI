Qualified data: runs/fp8-screen/.
Five eight-update replay/cache runs, six matched 256-update learning runs,
and 84 synthetic timing cases in eight files (two repeats, reversed order).
Final full tests: runs/fp8-final-suite.*; standalone FP8 tests: runs/fp8-tests-final.*.
Attribution profile: runs/fp8-profile.* (profiling overhead, not throughput).
The initial profile and exact original collector are retained as fp8-profile-initial*.
The final collector separates device types and groups actual kernel/copy events
to avoid double-counting GPU annotation ranges; numerical functions are unchanged.
Original 401-file checkpoint hashes: runs/fp8-checkpoint-{before,after}.json.
Installed package inventory/source hashes: runs/fp8-environment.json.
Executed source snapshots: runs/fp8-source-snapshot/.
Excluded pilots: runs/fp8-screen-pilot/ and runs/fp8-model-smoke.*.
The pilot linear sweep was interrupted to harden cache lifetime/inference reuse.
Early test failures exposed the compile region's specialization limit; the
final implementation has an explicit per-region limit and passed qualification.
Only the final complete controlled data are used for conclusions. No weights
or package binaries are included. Old report paths can retain their original
output locations; the archive directory identifies their qualification status.
All GPU processes were externally monitored, including compilation and warmup.
