import os, sys, subprocess, json, hashlib
from pathlib import Path
root=Path('/home/nir/ml-tools/mini-AGI');os.chdir(root)
p=str(root/'.venv/bin/python');out=root/'runs/performance/expert-backends';out.mkdir(parents=True,exist_ok=True)
base=['--weights','/mnt/fast/models/mini-AGI/undertrained/weights','--text','/mnt/fast/models/mini-AGI/evaluation-data/TinyStoriesV2-GPT4-valid.txt','--no-profile']
commands=[]
for checkpoint in [True,False]:
 for kind,script in [('legacy','/tmp/minagi-legacy-profile.py'),('reference','replication/profile_training.py')]:
  name=kind+('-checkpoint' if checkpoint else '-no-checkpoint')+'-equivalence'
  target=out/(name+'.json')
  cmd=[p,'-m','replication.gpu_monitor','--out',str(out/(name+'.power.json')),'--',p,script,*base,'--out',str(target),'--warmup','1','--steps','5','--deterministic','--state-digests']
  if not checkpoint:cmd+=['--no-checkpoint']
  commands.append(cmd);print('Starting '+name,flush=True)
  with open('/tmp/minagi-'+name+'.log','w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
  print(name,r.returncode,flush=True)
  if r.returncode:raise SystemExit(r.returncode)
results={}
for checkpoint in [True,False]:
 suffix=('-checkpoint' if checkpoint else '-no-checkpoint')+'-equivalence'
 old=json.loads((out/('legacy'+suffix+'.json')).read_text());new=json.loads((out/('reference'+suffix+'.json')).read_text())
 results[suffix]={'state_digests_identical':old['training_state_digests']==new['training_state_digests'],'losses_identical':old['losses']==new['losses'],'updates_including_warmup':6}
 assert all(results[suffix][k] for k in ('state_digests_identical','losses_identical')),results
(out/'reference-equivalence.json').write_text(json.dumps({'base_commit':'d0f581a','checks':results,'commands':commands,'source_sha256':{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in ['minagi/pool.py','minagi/expert_compute.py','replication/profile_training.py']}},indent=2)+'\n')
print(json.dumps(results),flush=True)
