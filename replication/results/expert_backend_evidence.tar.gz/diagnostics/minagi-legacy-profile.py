import sys, importlib.util
sys.path.insert(0, "/home/nir/ml-tools/mini-AGI")
spec = importlib.util.spec_from_file_location("minagi._legacy_pool", "/tmp/minagi-original-pool.py")
legacy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(legacy)
from minagi.pool import PooledMLP
PooledMLP._route = legacy.PooledMLP._route
PooledMLP._few = staticmethod(legacy.PooledMLP._few)
PooledMLP._runs = staticmethod(legacy.PooledMLP._runs)
from replication.profile_training import main
main()
