"""Preserve controlled accumulator evidence, binaries/disassembly, and pilots."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
root=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert (root/'runs/accum-verification-complete.txt').read_text().strip()=='passed'
r=json.loads((root/'replication/results/accumulation.json').read_text());assert r['status']=='passed'
monitors=sorted((root/'runs/accum-screen').rglob('*.external-power.json'));assert len(monitors)==38,len(monitors)
for p in monitors:
 v=json.loads(p.read_text());assert v['returncode']==0 and not v['errors'],str(p)
sources=list(root.glob('replication/*accum*.py'))+list(root.glob('minagi/*.py'))+list(root.glob('tests/*.py'))
sources += [root/p for p in ('train.py','config.yaml','AGENTS.md','TRAIN.md','replication/ACCUMULATION.md',
                             'replication/fp8_experts.py','replication/gpu_monitor.py','replication/probe_nvfp4.py',
                             'replication/run_fp8_screen.py','replication/compare_gefen_training.py','tests/test_accum_experts.py')]
for p in sources:
 dest=root/'runs/accum-source-snapshot'/p.relative_to(root);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
(root/'runs/accum-evidence-README.md').write_text('''Qualified experiment data: runs/accum-screen/.
Eleven eight-update replay/cache runs, fifteen matched 256-update learning runs,
and 76 synthetic timing cases in twelve files (two repeats, reversed method order).
Final full tests: runs/accum-final-suite.*; focused qualification: runs/accum-tests.*.
Disassembly: runs/accum-instructions.json and runs/accum-instructions/.
QuACK task-local AOT objects: runs/accum-quack-cache/ (not installed binaries).
Original 401-file checkpoint hashes: runs/accum-checkpoint-{before,after}.json.
Installed package inventory/source hashes: runs/accum-environment.json.
Executed source snapshots: runs/accum-source-snapshot/.
Excluded exploratory data: accum-spike*, accum-instructions-pilot*,
accum-instructions-v2*, accum-sass-pilot*, and accum-tests-pilot*.
The initial constructor-only spike failed because the register fragment helper
still allocated FP32; the qualified adapter changes both choices. The pilot test
suite imported the FP8 test class and skipped those eight tests; the corrected
focused suite has eight accumulator tests with no skips.
Only the final controlled data support conclusions. No model weights or installed
package binaries are included. GPU processes were externally monitored, including
compilation/warmup. CPU disassembly executes no CUDA kernels.
''')
paths=[]
for p in sorted((root/'runs').glob('accum*')):paths.extend(sorted(p.rglob('*')) if p.is_dir() else [p])
paths += [root/'runs/continue_accum_study.py',root/'runs/finalize_accum_study.py',Path(__file__).resolve()]
excluded={'accum-evidence-index.json','accum-archive-verification.log'}
paths=sorted({p for p in paths if p.is_file() and p.name not in excluded})
index={str(p.relative_to(root)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in paths}
index_path=root/'runs/accum-evidence-index.json';index_path.write_text(json.dumps(index,indent=2)+'\n')
archive=root/'replication/results/accumulation_evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in [*paths,index_path]:tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for name,entry in index.items():
  data=tar.extractfile(name).read();assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256'],name
checks={}
for tag in ('accum-final-suite','accum-tests'):
 p=root/f'runs/{tag}.power.json';t=json.loads(p.read_text());assert t['returncode']==0 and not t['errors']
 log=(root/f'runs/{tag}.log').read_text();count=re.search(r'Ran (\d+) tests?',log)
 checks[tag]=dict(test_count=int(count.group(1)),skipped_count=int(re.search(r'skipped=(\d+)',log).group(1)) if 'skipped=' in log else 0,
                 gpu_metadata=t['metadata'],whole_process=t['whole_process'],log=f'runs/{tag}.log',telemetry=str(p.relative_to(root)))
before=json.loads((root/'runs/accum-checkpoint-before.json').read_text());after=json.loads((root/'runs/accum-checkpoint-after.json').read_text());assert before==after
verification=dict(status='passed',git_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),tests=checks,
 learning_trial_count=15,synthetic_timing_cases=len(r['probes']),monitored_experiment_processes=len(monitors),
 replay_gate=r['reproducibility'],original_checkpoint_unchanged_files=len(before),measured_source_sha256=r['learning_runs'][0]['source_sha256'],
 instructions=json.loads((root/'runs/accum-instructions.json').read_text())['instructions'],
 environment=json.loads((root/'runs/accum-environment.json').read_text()),
 evidence_archive=dict(path=str(archive.relative_to(root)),sha256=sha(archive),bytes=archive.stat().st_size,verified_file_count=len(index)))
(root/'replication/results/accumulation_verification.json').write_text(json.dumps(verification,indent=2)+'\n')
print(json.dumps({k:v for k,v in verification.items() if k!='environment'},indent=2))
