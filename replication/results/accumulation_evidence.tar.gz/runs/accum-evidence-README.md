Qualified experiment data: runs/accum-screen/.
Eleven eight-update replay/cache runs, fifteen matched 256-update learning runs,
and 76 synthetic timing cases in twelve files (two repeats, reversed method order).
Final full tests: runs/accum-final-suite.*; focused qualification: runs/accum-tests.*.
Disassembly: runs/accum-instructions.json and runs/accum-instructions/.
QuACK task-local AOT objects: runs/accum-quack-cache/ (not installed binaries).
Original 401-file checkpoint hashes: runs/accum-checkpoint-{before,after}.json.
Installed package inventory/source hashes: runs/accum-environment.json.
Executed source snapshots: runs/accum-source-snapshot/.
Excluded exploratory data: accum-spike*, accum-instructions-pilot*,
accum-instructions-v2*, accum-sass-pilot*, and accum-tests-pilot*.
The initial constructor-only spike failed because the register fragment helper
still allocated FP32; the qualified adapter changes both choices. The pilot test
suite imported the FP8 test class and skipped those eight tests; the corrected
focused suite has eight accumulator tests with no skips.
Only the final controlled data support conclusions. No model weights or installed
package binaries are included. GPU processes were externally monitored, including
compilation/warmup. CPU disassembly executes no CUDA kernels.
