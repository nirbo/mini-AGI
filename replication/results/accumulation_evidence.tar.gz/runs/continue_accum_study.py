import json
from pathlib import Path
import subprocess
import sys
import time
last=Path('runs/accum-screen/experts-large-repeat2.json')
while True:
 if last.exists():
  r=json.loads(last.read_text())
  if r.get('status')=='passed' and all('external_power' in c for c in r['cases']):break
 time.sleep(5)
for phase in ('repro','learning'):
 print('starting',phase,flush=True)
 with Path(f'runs/accum-{phase}.log').open('w') as log:
  subprocess.run([sys.executable,'-m','replication.run_accumulation_screen','--phase',phase],stdout=log,stderr=subprocess.STDOUT,check=True)
 print('finished',phase,flush=True)
Path('runs/accum-study-complete.txt').write_text('passed\n')
