import hashlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

root=Path(__file__).resolve().parents[1];os.chdir(root)
while not Path('runs/accum-study-complete.txt').exists():time.sleep(5)
env=os.environ|dict(PATH=str(root/'.venv/bin')+os.pathsep+os.environ['PATH'],
                   CUBLAS_WORKSPACE_CONFIG=':4096:8',MINAGI_GEFEN_ALLOW_CUDA_MINOR_MISMATCH='1',
                   MINAGI_FP8_TEST_CUDA='1',MINAGI_ACCUM_TEST_CUDA='1',
                   TORCHINDUCTOR_COMPILE_THREADS='2',MAX_JOBS='2')
print('starting final full regression suite',flush=True)
with Path('runs/accum-final-suite.log').open('w') as log:
 subprocess.run([sys.executable,'-m','replication.gpu_monitor','--out','runs/accum-final-suite.power.json','--',
                 sys.executable,'-m','unittest','discover','-s','tests','-v'],env=env,
                stdout=log,stderr=subprocess.STDOUT,check=True)
print('full suite passed',flush=True)
subprocess.run([sys.executable,'-m','replication.inspect_accum_kernels','--out','runs/accum-instructions.json'],check=True)
before=json.loads(Path('runs/accum-checkpoint-before.json').read_text());weights=Path('/mnt/fast/models/mini-AGI/undertrained/weights');after={}
for p in sorted(weights.rglob('*')):
 if not p.is_file():continue
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
 after[str(p.relative_to(weights))]=dict(bytes=p.stat().st_size,sha256=h.hexdigest())
Path('runs/accum-checkpoint-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after
print('original checkpoint unchanged',len(after),flush=True)
packages={n:importlib.metadata.version(n) for n in ('torch','triton','quack-kernels','nvidia-cutlass-dsl','sonic-moe','gefen','numpy','nvidia-ml-py')}
installed={}
for name in ('quack','sonicmoe','gefen'):
 package=Path(next(iter(importlib.util.find_spec(name).submodule_search_locations)))
 installed[name]={str(p.relative_to(package)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(package.rglob('*'))
                  if p.is_file() and p.suffix in ('.py','.cu','.cuh','.cpp','.h','.hpp')}
previous=json.loads(Path('runs/fp8-environment.json').read_text())['installed_source_sha256']
assert installed==previous,'installed packages changed'
import torch
Path('runs/accum-environment.json').write_text(json.dumps(dict(platform=platform.platform(),python=platform.python_version(),packages=packages,
 torch_version=torch.__version__,torch_cuda_build=torch.version.cuda,
 git_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 cuda_toolkit=subprocess.check_output(['nvcc','--version'],text=True),installed_source_sha256=installed,
 installed_sources_unchanged_from_fp8_study=True),indent=2)+'\n')
subprocess.run([sys.executable,'-m','replication.summarize_accumulation'],check=True)
Path('runs/accum-verification-complete.txt').write_text('passed\n')
print('verification complete',flush=True)
